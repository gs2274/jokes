# random-joke-generator-jquery-ajax
This is a simple Random joke generator using the Rest API in jQuery Ajax by Brave Coder
